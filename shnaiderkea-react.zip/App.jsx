import React from 'react'

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Добро пожаловать в ShnaiderKea!</h1>
      <p>Скоро вы сможете загружать фото, выбирать материалы и визуализировать интерьер прямо здесь.</p>
    </div>
  )
}

export default App
