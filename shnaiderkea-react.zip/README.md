# ShnaiderKea React Frontend

Простой старт для проекта на Vite + React.
